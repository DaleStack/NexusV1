# Nexus
---
### Data Type
```
int, float, str, bool
```
### Variable Declaration
Empty Variable
```
var a
var b
```
Empty Typed Variable
```
var a str
var b int
var c float
var d bool
```
Variable with Value
```
var a = "John"
var b = 12
var c = 3.14
var d = True
```
Typed Variable with Value
```
var a str = "John"
var b int = 12
var c float = 3.14
var d bool = True
```
### Output Declaration
```
say("Hello World")
```

Printing a Variable
```
var greet = "Hello World"

say(greet)
```
Printing String with Variable
```
var a = "World"

say("Hello, " + a)
```
